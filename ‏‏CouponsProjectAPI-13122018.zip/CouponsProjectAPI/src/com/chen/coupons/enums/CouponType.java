package com.chen.coupons.enums;

public enum CouponType {
	
	Food ,Electronic,Leisuer,Holiday;

	
}
