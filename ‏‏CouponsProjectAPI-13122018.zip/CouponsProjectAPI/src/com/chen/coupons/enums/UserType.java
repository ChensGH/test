package com.chen.coupons.enums;

public enum UserType {
	
	COMPANY,CUSTOMER;

}
